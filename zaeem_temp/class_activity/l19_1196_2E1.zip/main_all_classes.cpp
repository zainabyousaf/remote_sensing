// Aggregation and composition
// l19-1196 CS-2E1
// zaeem Yousaf
// class point

#include "all_classes.h"
#include "all_classes.cpp"
#include <iostream>
using namespace std;

int main(){
Point p1(2,3);
p1.print();

Circle c1(2,3,3.5);
c1.print();

Student s1( "12L1111",  "Hashim Amla" , 3.99);
Student s2( "13L1121" ,  "Virat Kohli" , 3.45);
Student s3( "13L1126" ,  "Quinton de Kock" , 2.98);
Student s4( "14L1361" ,  "Joe Root" ,2.99);
Student s5( "14L1124" ,  "Martin Guptil" , 3.09);
Student s6( "15L1314" ,  "Rohit Sharma" , 3.19);

Society sports("Sports");
sports.PrintInfo();

sports.AppointPresident(s3);
sports.AppointPresident(s1);
sports.AppointPresident(s2);

sports.PrintInfo();
}
